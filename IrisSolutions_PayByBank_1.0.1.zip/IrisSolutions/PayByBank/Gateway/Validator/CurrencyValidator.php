<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Validator;

use Exception;
use IrisSolutions\PayByBank\Gateway\Config\Config;
use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Magento\Payment\Gateway\Validator\ResultInterfaceFactory;

/**
 * @api
 * @since 100.0.2
 */
class CurrencyValidator extends AbstractValidator
{
    /**
     * @var Config
     */
    private Config $config;

    /**
     * @param ResultInterfaceFactory $resultFactory
     * @param Config $config
     */
    public function __construct(
        ResultInterfaceFactory $resultFactory,
        Config $config
    ) {
        $this->config = $config;
        parent::__construct($resultFactory);
    }

    /**
     * Validate country
     *
     * @param array $validationSubject
     * @return ResultInterface
     * @throws Exception
     */
    public function validate(array $validationSubject)
    {
        $storeId = $validationSubject['storeId'];
        $isValid = !empty($this->config->getTolban($validationSubject['currency'], $storeId));

        return $this->createResult($isValid);
    }
}
