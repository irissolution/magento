<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Payment\Gateway\ConfigInterface;
use IrisSolutions\PayByBank\Model\Ui\ConfigProvider;
use Magento\Store\Model\StoreManagerInterface;

class Config extends \Magento\Payment\Gateway\Config\Config implements ConfigInterface
{
    private const ACTIVE = 'active';

    private const SANDBOX = 'sandbox';

    private const MERCHANT_KEY = 'merchant_key';

    private const TOLBAN = 'tolban';

    public const API_URL_PRODUCTION = 'https://paybyclick.irispay.bg/';

    public const API_URL_SANDBOX = 'https://payperclick.infn.dev/';

    public const SUPPORTED_CURRENCIES = ['BGN', 'RON', 'EUR'];

    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param Json $json
     * @param string $methodCode
     * @param string $pathPattern
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        Json $json,
        string $methodCode = ConfigProvider::CODE,
        string $pathPattern = self::DEFAULT_PATH_PATTERN
    ) {
        $this->storeManager = $storeManager;
        $this->json = $json;

        parent::__construct($scopeConfig, $methodCode, $pathPattern);
    }

    /**
     * Get Payment configuration status
     *
     * @param int|null $storeId
     *
     * @return bool
     * @throws NoSuchEntityException
     */
    public function isActive(int $storeId = null): bool
    {
        return (bool)$this->getValue(
            self::ACTIVE,
            $storeId ?? $this->storeManager->getStore()->getId()
        );
    }

    /**
     * Payment processor mode - test or production.
     *
     * @param int|null $storeId
     * @return bool
     */
    public function isSandbox(?int $storeId = null): bool
    {
        return (bool)$this->getValue(self::SANDBOX, $storeId);
    }

    /**
     * Get Payment Processor URL.
     *
     * @param int|null $storeId
     * @return string
     * @throws NoSuchEntityException
     */
    public function getUrl(?int $storeId = null): string
    {
        if ($this->isSandbox($storeId)) {
            return self::API_URL_SANDBOX;
        }

        return self::API_URL_PRODUCTION;
    }

    /**
     * Gets merchant ID.
     *
     * @param int|null $storeId
     *
     * @return string
     */
    public function getMerchantKey(?int $storeId = null): string
    {
        return (string)$this->getValue(self::MERCHANT_KEY, $storeId);
    }

    /**
     * Get Tolban.
     *
     * @param string $currency
     * @param int|null $storeId
     * @return string[][]
     */
    public function getTolban(string $currency, ?int $storeId = null): array
    {
        $tolban = [];
        if ($config = $this->getValue(self::TOLBAN, $storeId)) {
            $tolbans = $this->json->unserialize($config);

            if (is_array($tolbans)) {
                foreach ($tolbans as $item) {
                    $tolban[$item['currency']] = $item;
                }
            }
        }

        return $tolban[$currency] ?? [];
    }
}
