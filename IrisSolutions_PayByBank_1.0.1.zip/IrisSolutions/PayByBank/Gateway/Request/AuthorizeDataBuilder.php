<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Request;

use IrisSolutions\PayByBank\Gateway\Config\Config;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\PaymentException;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Helper\Formatter;
use Magento\Store\Api\StoreRepositoryInterface;

class AuthorizeDataBuilder implements BuilderInterface
{
    use Formatter;

    /**
     * @var UrlInterface
     */
    private UrlInterface $url;

    /**
     * @var Config
     */
    private Config $config;

    /**
     * @var StoreRepositoryInterface
     */
    private StoreRepositoryInterface $storeRepository;

    /**
     * @var Resolver
     */
    private Resolver $localeResolver;

    /**
     * ConfigProvider constructor.
     *
     * @param UrlInterface $url
     * @param Config $config
     * @param StoreRepositoryInterface $storeRepository
     * @param Resolver $localeResolver
     */
    public function __construct(
        UrlInterface             $url,
        Config                   $config,
        StoreRepositoryInterface $storeRepository,
        Resolver                 $localeResolver,
    ) {
        $this->url = $url;
        $this->config = $config;
        $this->storeRepository = $storeRepository;
        $this->localeResolver = $localeResolver;
    }

    /**
     * @inheritdoc
     * @throws PaymentException
     * @throws NoSuchEntityException
     */
    public function build(array $buildSubject): array
    {
        if (!isset($buildSubject['payment'])) {
            throw new PaymentException(__('Payment Information missing.'));
        }

        $order = $buildSubject['payment']->getOrder();

        $store = $this->storeRepository->getById($order->getStoreId());
        return [
            'currency' => $order->getCurrencyCode(),
            'description' => $store->getName(),
            'hookUrl' => $this->url->getUrl(
                'paybybank/processing/update',
                [
                    'order_id' => $order->getOrderIncrementId(),
                    '_secure' => true
                ]
            ),
            'redirectUrl' => $this->url->getUrl('paybybank/processing/result', ['_secure' => true]),
            'name' =>  __('Order #%1', $order->getOrderIncrementId())->render(),
            'orderId' =>  $order->getOrderIncrementId(),
            'sum' => $this->formatPrice($order->getGrandTotalAmount()),
            'tolban' => $this->config->getTolban($order->getCurrencyCode(), $order->getStoreId()),
            'lang' => substr($this->localeResolver->getLocale(), 0, 2)
        ];
    }
}
