<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Http\Client;

use Exception;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use IrisSolutions\PayByBank\Gateway\Config\Config;
use Laminas\Http\Request;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\TransactionInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;

class UpdateOrderStatus
{
    /**
     * @var ClientFactory
     */
    private ClientFactory $clientFactory;

    /**
     * @var Config
     */
    private Config $config;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @var BuilderInterface
     */
    private BuilderInterface $transactionBuilder;

    /**
     * @var OrderManagementInterface
     */
    private OrderManagementInterface $orderManagement;

    /**
     * @param ClientFactory $clientFactory
     * @param Config $config
     * @param Json $json
     * @param BuilderInterface $transactionBuilder
     * @param OrderManagementInterface $orderManagement
     */
    public function __construct(
        ClientFactory            $clientFactory,
        Config                   $config,
        Json                     $json,
        BuilderInterface         $transactionBuilder,
        OrderManagementInterface $orderManagement
    ) {
        $this->clientFactory = $clientFactory;
        $this->config = $config;
        $this->transactionBuilder = $transactionBuilder;
        $this->orderManagement = $orderManagement;
        $this->json = $json;
    }

    /**
     * Update Order Status based on the response of the payment processor.
     *
     * @param $order
     * @return array|false
     * @throws NoSuchEntityException
     */
    public function execute($order)
    {
        $additionalInfo = $order->getPayment()->getAdditionalInformation();
        preg_match(
            '/^https:\/\/[a-z\.]+\/#\/payment\/link\/([0-9a-z]+)$/',
            $additionalInfo['payment_link'],
            $matches
        );

        if ($paymentId = $matches[1]) {
            $client = $this->clientFactory->create(['config' => [
                'base_uri' => $this->config->getUrl((int)$order->getStoreId()),
                RequestOptions::HEADERS => [
                    'Content-type' => 'application/json; charset=utf-8',
                    'Accept' => 'application/json'
                ]
            ]]);

            try {
                $response = $client->request(
                    Request::METHOD_GET,
                    'backend/payment/status/' . $paymentId
                );

                $response = $this->json->unserialize($response->getBody()->getContents());

                if (isset($response['status'])) {
                    switch ($response['status']) {
                        case 'CONFIRMED':
                            $this->confirmPayment($order, $paymentId);
                            break;
                        case 'FAILED':
                            $this->cancelPayment($order);
                            break;
                    }

                    return $response['status'];
                }

                return false;

            } catch (RequestException|GuzzleException|Exception $e) {
                return false;
            }
        }

        return false;
    }

    /**
     * Set Payment as confirmed.
     *
     * @param OrderInterface $order
     * @param string $paymentId
     * @return void
     * @throws Exception
     */
    private function confirmPayment(OrderInterface $order, string $paymentId): void
    {
        $payment = $order->getPayment();
        $payment->setLastTransId($paymentId);
        $payment->setTransactionId($paymentId); // @phpstan-ignore-line

        $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal()); // @phpstan-ignore-line
        $message = __('The captured amount is %1.', $formatedPrice);

        $transaction = $this->transactionBuilder->setPayment($payment)
            ->setOrder($order)
            ->setTransactionId($paymentId)
            ->setFailSafe(true)
            ->build(TransactionInterface::TYPE_CAPTURE);

        $payment->addTransactionCommentsToOrder($transaction, $message); // @phpstan-ignore-line
        $payment->setParentTransactionId(null); // @phpstan-ignore-line
        $payment->save(); // @phpstan-ignore-line

        $order->setState('processing');
        $order->addCommentToStatusHistory(__('Payment Accepted')->render(), 'processing'); // @phpstan-ignore-line
        $order->save(); // @phpstan-ignore-line
    }

    /**
     * Cancel payment and order.
     *
     * @param OrderInterface $order
     * @return void
     */
    private function cancelPayment(OrderInterface $order): void
    {
        try {
            $this->orderManagement->cancel($order->getId());
            $order->addCommentToStatusHistory(__('Payment failed.')->render(), 'closed');
            $order->save();
        } catch (\Exception $e) {
        }
    }
}
