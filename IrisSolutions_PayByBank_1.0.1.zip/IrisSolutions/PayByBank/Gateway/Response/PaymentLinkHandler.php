<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Response;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\PaymentException;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Sales\Model\Order\Payment;

class PaymentLinkHandler implements HandlerInterface
{
    /**
     * Handles response
     *
     * @param array $handlingSubject
     * @param array $response
     * @return void
     * @throws PaymentException
     * @throws LocalizedException
     */
    public function handle(array $handlingSubject, array $response)
    {
        if (!isset($handlingSubject['payment'])) {
            throw new PaymentException(__('Payment Information missing.'));
        }

        $paymentDataObject = $handlingSubject['payment'];
        /** @var Payment $payment */
        $payment = $paymentDataObject->getPayment();
        $payment->setIsTransactionPending(true);
        $payment->getOrder()->addCommentToStatusHistory(__('Payment Link Generated')->render(), 'pending_payment');
        $payment->setAdditionalInformation('account_id', $response['accountId']);
        $payment->setAdditionalInformation('payment_link', $response['paymentLink']);
    }
}
