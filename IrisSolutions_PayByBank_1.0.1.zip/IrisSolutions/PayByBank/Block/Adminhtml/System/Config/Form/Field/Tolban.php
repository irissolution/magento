<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Block\Adminhtml\System\Config\Form\Field;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;
use Magento\Framework\Exception\LocalizedException;

/**
 * @SuppressWarnings(PHPMD.LongVariable)
 * @SuppressWarnings(PHPMD.CamelCasePropertyName)
 * @SuppressWarnings(PHPMD.CamelCaseMethodName)
 */
class Tolban extends AbstractFieldArray
{
    /**
     * Add Renreder.
     *
     * @return void
     */
    protected function _prepareToRender(): void
    {
        try {
            $this->addColumn('currency', [
                'label' => __('Account Currency'),
                'renderer' =>  $this->getLayout()->createBlock(Currency::class)
            ]);

            $this->addColumn('iban', ['label' => __('IBAN')]);

            $this->_addAfter = false;
            $this->_addButtonLabel = __('Add')->render();
        } catch (LocalizedException $e) {
            throw new \RuntimeException($e->getMessage());
        }
        $this->_construct();
    }
}
