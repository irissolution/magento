<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Block\Adminhtml\System\Config\Form\Field;

use IrisSolutions\PayByBank\Gateway\Config\Config;
use Magento\Framework\Currency\Exception\CurrencyException;
use Magento\Framework\Locale\CurrencyInterface;
use Magento\Framework\View\Element\Context;
use Magento\Framework\View\Element\Html\Select;

class Currency extends Select
{
    /**
     * @var CurrencyInterface
     */
    private CurrencyInterface $localeCurrency;

    /**
     * @param Context $context
     * @param CurrencyInterface $localeCurrency
     * @param array $data
     */
    public function __construct(
        Context $context,
        CurrencyInterface $localeCurrency,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->localeCurrency = $localeCurrency;
    }

    /**
     * Render.
     *
     * @return string
     * @throws CurrencyException
     */
    protected function _toHtml(): string
    {
        $this->setId($this->getData('input_id'));
        $this->setData('name', $this->getData('input_name'));

        if (!$this->getOptions()) {
            $supportedCurrencies = [];
            foreach (Config::SUPPORTED_CURRENCIES as $currency) {
                $supportedCurrencies[] = [
                    'value' => $currency,
                    'label' => $this->localeCurrency->getCurrency($currency)->getName(),
                ];
            }

            $this->setOptions($supportedCurrencies);
        }

        return parent::_toHtml();
    }
}
