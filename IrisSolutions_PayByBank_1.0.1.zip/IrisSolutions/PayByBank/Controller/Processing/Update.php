<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Controller\Processing;

use Exception;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use IrisSolutions\PayByBank\Gateway\Http\Client\UpdateOrderStatus;
use Magento\Sales\Model\OrderFactory;

class Update implements HttpPostActionInterface, CsrfAwareActionInterface
{
    /**
     * @var RequestInterface
     */
    private RequestInterface $request;

    /**
     * @var OrderFactory
     */
    private OrderFactory $orderFactory;

    /**
     * @var UpdateOrderStatus
     */
    private UpdateOrderStatus $updateOrderStatus;

    /**
     * @param RequestInterface $request
     * @param OrderFactory $orderFactory
     * @param UpdateOrderStatus $updateOrderStatus
     */
    public function __construct(
        RequestInterface $request,
        OrderFactory $orderFactory,
        UpdateOrderStatus $updateOrderStatus
    ) {
        $this->request = $request;

        $this->updateOrderStatus = $updateOrderStatus;
        $this->orderFactory = $orderFactory;
    }

    /**
     * Update Order based on the data from payment provider.
     *
     * @return void
     * @throws Exception
     */
    public function execute(): void
    {
        if ($orderId = $this->request->getParam('order_id')) {
            $order = $this->orderFactory->create()->loadByIncrementId($orderId);
            $this->updateOrderStatus->execute($order);
        }
    }

    /**
     * Mute execptions from external requests CSRF validation.
     *
     * @param RequestInterface $request
     *
     * @return InvalidRequestException|null
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
     * Ignore CSRF Validatation for external requests.
     *
     * @param RequestInterface $request
     *
     * @return bool|null
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}
