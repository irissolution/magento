<?php

/** @noinspection PhpUnusedPrivateFieldInspection */

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Store\Model\ScopeInterface;
use IrisSolutions\PayByBank\Model\Ui\ConfigProvider;
use Magento\Store\Model\StoreManagerInterface;

class Config extends \Magento\Payment\Gateway\Config\Config implements ConfigInterface
{
    private const KEY_ACTIVE = 'active';

    private const MERCHANT_KEY = 'merchant_key';

    private const TOLBAN = 'tolban';

    public const API_URL = 'https://payperclick.infn.dev/';
    // public const API_URL = 'https://payperclick.irispay.bg/';

    /**
     * @var StoreManagerInterface
     */
    private StoreManagerInterface $storeManager;

    /**
     * @var ScopeConfigInterface
     */
    private ScopeConfigInterface $scopeConfig;

    /**
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param string $methodCode
     * @param string $pathPattern
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        string $methodCode = ConfigProvider::CODE,
        string $pathPattern = self::DEFAULT_PATH_PATTERN
    ) {
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;

        parent::__construct($scopeConfig, $methodCode, $pathPattern);
    }

    /**
     * Get Payment configuration status
     *
     * @param int|null $storeId
     *
     * @return bool
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function isActive(int $storeId = null): bool
    {
        return (bool)$this->getValue(
            self::KEY_ACTIVE,
            $storeId ?? $this->storeManager->getStore()->getId()
        );
    }

    /**
     * Gets merchant ID.
     *
     * @param int|null $storeId
     *
     * @return string
     */
    public function getMerchantKey(?int $storeId = null): string
    {
        return (string)$this->getValue(self::MERCHANT_KEY, $storeId);
    }

    /**
     * Get Tolban.
     *
     * @param int|null $storeId
     * @return string|null
     */
    public function getTolban(?int $storeId = null): ?string
    {
        return (string)$this->getValue(self::TOLBAN, $storeId);
    }

    /**
     * Get Store Email Address, used for request to payment processor.
     *
     * @param int|null $storeId
     *
     * @return string|null
     */
    public function getStoreEmail(int $storeId = null): ?string
    {
        return $this->scopeConfig->getValue(
            'trans_email/ident_sales/email',
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
}
