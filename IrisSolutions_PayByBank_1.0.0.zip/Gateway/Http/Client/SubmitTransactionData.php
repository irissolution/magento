<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Http\Client;

use Exception;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Psr7\ResponseFactory;
use GuzzleHttp\RequestOptions;
use Laminas\Http\Request;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Model\Method\Logger;
use Psr\Log\LoggerInterface;
use IrisSolutions\PayByBank\Gateway\Config\Config;

class SubmitTransactionData implements ClientInterface
{
    /**
     * @var LoggerInterface
     */
    protected LoggerInterface $logger;

    /**
     * @var Logger
     */
    private Logger $paymentLogger;

    /**
     * @var ClientFactory
     */
    private ClientFactory $clientFactory;

    /**
     * @var ResponseFactory
     */
    private ResponseFactory $responseFactory;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * Constructor
     *
     * @param ClientFactory $clientFactory
     * @param ResponseFactory $responseFactory
     * @param Json $json
     * @param LoggerInterface $logger
     * @param Logger $paymentLogger
     */
    public function __construct(
        ClientFactory   $clientFactory,
        ResponseFactory $responseFactory,
        Json            $json,
        LoggerInterface $logger,
        Logger          $paymentLogger
    ) {
        $this->clientFactory = $clientFactory;
        $this->responseFactory = $responseFactory;
        $this->json = $json;
        $this->logger = $logger;
        $this->paymentLogger = $paymentLogger;
    }

    /**
     * @inheritdoc
     */
    public function placeRequest(TransferInterface $transferObject): array
    {
        $data = $transferObject->getBody();
        $log = [
            'request' => $data,
            'client' => static::class
        ];

        $response = [];
        try {
            $response = $this->process($transferObject);
        } catch (Exception $e) {
            $message = __($e->getMessage() ?: 'Sorry, but something went wrong');
            $this->logger->critical($message);
            throw new ClientException($message);
        } finally {
            $log['response'] = $response;
            $this->paymentLogger->debug($log);
        }

        return $response;
    }

    /**
     * Get Payment Link.
     *
     * @param TransferInterface $transfer
     * @return array
     * @throws Exception
     */
    private function process(TransferInterface $transfer): array
    {
        $client = $this->clientFactory->create(['config' => [
            'base_uri' => Config::API_URL,
            RequestOptions::HEADERS => $transfer->getHeaders() ?:  [
                'Content-type' => 'application/json; charset=utf-8',
                'Accept' => 'application/json'
            ]
        ]]);

        try {
            $response = $client->request(
                $transfer->getMethod() ?: Request::METHOD_POST,
                'backend/payment/' . $transfer->getUri(),
                [RequestOptions::JSON => $transfer->getBody()]
            );
        } catch (RequestException $e) {
            $response = $this->responseFactory->create([
                'status' => $e->getCode(),
                'message' => $e->getResponse()->getBody()->getContents()
            ]);
        } catch (GuzzleException $e) {
            $response = $this->responseFactory->create([
                'status' => $e->getCode(),
                'message' => $e->getMessage()
            ]);
        }

        if ($response->getStatusCode() >= 200 && $response->getStatusCode() < 300) {
            $responseContents = $response->getBody()->getContents();

            return $this->json->unserialize($responseContents);
        }

        throw new Exception($response->getBody()->getContents(), $response->getStatusCode());
    }
}
