<?php
/*
 * @package      Webcode_Fibank
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2022 Webcode Ltd. (https://webcode.bg/)
 * @license      Visit https://webcode.bg/license/ for license details.
 */
namespace Webcode\Fibank\Gateway\Http\Client;

class ReversalRequest extends AbstractRequest
{
    /**
     * @inheritdoc
     */
    protected function process(array $data)
    {
        echo  json_encode(['success' => true, 'redirect' => 'https://fibank.bg/']);
        exit;
        // return $this->adapter->sale($data);
    }
}
