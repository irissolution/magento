<?php
/**
 * @package      Webcode_magento
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2023 Webcode Ltd. (https://webcode.bg/)
 * @license      Visit https://webcode.bg/license/ for license details.
 */

namespace IrisSolutions\PayByBank\Gateway\Http\Client;

use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Psr7\ResponseFactory;
use GuzzleHttp\RequestOptions;
use IrisSolutions\PayByBank\Gateway\Config\Config;
use Laminas\Http\Request;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Payment\Model\Method\Logger;
use Psr\Log\LoggerInterface;

class CheckOrderStatus
{
    /**
     * @var ClientFactory
     */
    private ClientFactory $clientFactory;

    /**
     * @var ResponseFactory
     */
    private ResponseFactory $responseFactory;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * Constructor
     *
     * @param ClientFactory $clientFactory
     * @param ResponseFactory $responseFactory
     * @param Json $json
     * @param LoggerInterface $logger
     * @param Logger $paymentLogger
     */
    public function __construct(
        ClientFactory   $clientFactory,
        ResponseFactory $responseFactory,
        Json            $json,
        LoggerInterface $logger,
        Logger          $paymentLogger
    ) {
        $this->clientFactory = $clientFactory;
        $this->responseFactory = $responseFactory;
        $this->json = $json;
    }

    /**
     * @throws \Exception
     */
    public function execute($paymentId)
    {
        $client = $this->clientFactory->create(['config' => [
            'base_uri' => Config::API_URL,
            RequestOptions::HEADERS => [
                'Content-type' => 'application/json; charset=utf-8',
                'Accept' => 'application/json'
            ]
        ]]);

        try {
            $response = $client->request(
                Request::METHOD_GET,
                'backend/payment/status/' . $paymentId
            );
        } catch (RequestException $e) {
            $response = $this->responseFactory->create([
                'status' => $e->getCode(),
                'message' => $e->getResponse()->getBody()->getContents()
            ]);
        } catch (GuzzleException $e) {
            $response = $this->responseFactory->create([
                'status' => $e->getCode(),
                'message' => $e->getMessage()
            ]);
        }

        if ($response->getStatusCode() >= 200 && $response->getStatusCode() < 300) {
            $responseContents = $response->getBody()->getContents();

            return $this->json->unserialize($responseContents);
        }

        throw new \Exception($response->getBody()->getContents(), $response->getStatusCode());
    }
}
