<?php
namespace IrisSolutions\PayByBank\Gateway\Http\Client;

class TransactionSubmitForSettlement extends AbstractRequest
{
    /**
     * @param array $data
     * @return array
     */
    protected function process(array $data): array
    {
        return $data;
    }
}
