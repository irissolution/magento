<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Gateway\Http\Client;

use Exception;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use IrisSolutions\PayByBank\Gateway\Config\Config;
use Laminas\Http\Request;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\TransactionInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;
use Webcode\SyncMicroinvest\Cron\Syncronize\Order;

class UpdateOrderStatus
{
    /**
     * @var ClientFactory
     */
    private ClientFactory $clientFactory;

    /**
     * @var Json
     */
    private Json $json;

    /**
     * @var BuilderInterface
     */
    private BuilderInterface $transactionBuilder;

    /**
     * @var OrderManagementInterface
     */
    private OrderManagementInterface $orderManagement;

    /**
     * @param ClientFactory $clientFactory
     * @param Json $json
     * @param BuilderInterface $transactionBuilder
     * @param OrderManagementInterface $orderManagement
     */
    public function __construct(
        ClientFactory   $clientFactory,
        Json            $json,
        BuilderInterface $transactionBuilder,
        OrderManagementInterface $orderManagement
    ) {
        $this->clientFactory = $clientFactory;
        $this->transactionBuilder = $transactionBuilder;
        $this->orderManagement = $orderManagement;
        $this->json = $json;
    }

    /**
     * Update Order Status based on the response of the payment processor.
     *
     * @throws Exception
     */
    public function execute($order)
    {
        $additionalInfo = $order->getPayment()->getAdditionalInformation();
        preg_match(
            '/^https:\/\/[a-z\.]+\/#\/payment\/link\/([0-9a-z]+)$/',
            $additionalInfo['payment_link'],
            $matches
        );

        if ($paymentId = $matches[1]) {
            $client = $this->clientFactory->create(['config' => [
            'base_uri' => Config::API_URL,
            RequestOptions::HEADERS => [
                'Content-type' => 'application/json; charset=utf-8',
                'Accept' => 'application/json'
            ]
            ]]);

            try {
                $response = $client->request(
                    Request::METHOD_GET,
                    'backend/payment/status/' . $paymentId
                );

                $response = $this->json->unserialize($response->getBody()->getContents());

                if (isset($response['status'])) {
                    switch ($response['status']) {
                        case 'CONFIRMED':
                            $this->confirmPayment($order, $paymentId);
                            break;
                        case 'FAILED':
                            $this->cancelPayment($order);
                            break;
                    }

                    return $response['status'];
                }

                return false;

            } catch (RequestException|GuzzleException $e) {
                return false;
            }
        }

        return false;
    }

    /**
     * Set Payment as confirmed.
     *
     * @param OrderInterface $order
     * @param string $paymentId
     * @return void
     * @throws Exception
     */
    private function confirmPayment(OrderInterface $order, string $paymentId): void
    {
        $payment = $order->getPayment();
        $payment->setLastTransId($paymentId);
        $payment->setTransactionId($paymentId);

        $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal());
        $message = __('The captured amount is %1.', $formatedPrice);

        $transaction = $this->transactionBuilder->setPayment($payment)
            ->setOrder($order)
            ->setTransactionId($paymentId)
            ->setFailSafe(true)
            ->build(TransactionInterface::TYPE_CAPTURE);

        $payment->addTransactionCommentsToOrder($transaction, $message);
        $payment->setParentTransactionId(null);
        $payment->save();

        $order->addCommentToStatusHistory(__('Payment Accepted')->render(), 'processing');
        $order->save();
    }

    /**
     * Cancel payment and order.
     *
     * @param OrderInterface $order
     * @return void
     */
    private function cancelPayment(OrderInterface $order): void
    {
        try {
            $this->orderManagement->cancel($order->getId());
            $order->addCommentToStatusHistory(__('Payment failed.')->render(), 'closed');
            $order->save();
        } catch (\Exception $e) {
        }
    }
}
