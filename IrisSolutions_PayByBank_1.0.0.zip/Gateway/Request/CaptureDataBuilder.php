<?php

namespace IrisSolutions\PayByBank\Gateway\Request;

use Magento\Framework\Exception\LocalizedException;
use PayPal\Braintree\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Helper\Formatter;

class AuthorizeDataBuilder implements BuilderInterface
{
    use Formatter;

    public const TRANSACTION_ID = 'transaction_id';

    /**
     * @var SubjectReader
     */
    private $subjectReader;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     */
    public function __construct(SubjectReader $subjectReader)
    {
        $this->subjectReader = $subjectReader;
    }

    /**
     * @inheritdoc
     *
     * @throws LocalizedException
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        return [
            'currency' => $paymentDO->getOrder()->getCurrencyCode(),
            'description' => 'Order #' . $paymentDO->getOrder()->getOrderIncrementId(),
            'hookUrl' => 'https://magento2.bg/paybybank/result',
            'name' =>  'Order #' . $paymentDO->getOrder()->getOrderIncrementId(),
            'redirectUrl' =>  'https://magento2.bg/checkout/success',
            'orderId' =>  $paymentDO->getOrder()->getOrderIncrementId(),
            'sum' => $this->formatPrice($this->subjectReader->readAmount($buildSubject)),
            'tolban' => 'BG85IORT80947826532954',
            'lang' => 'bg'
        ];
    }
}
