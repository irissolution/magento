<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Cron;

use Exception;
use IrisSolutions\PayByBank\Gateway\Http\Client\UpdateOrderStatus;
use IrisSolutions\PayByBank\Model\Ui\ConfigProvider;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\Search\FilterGroup;
use Magento\Framework\Api\Search\FilterGroupBuilder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Sales\Api\OrderRepositoryInterface;

class UpdatePaymentStatus
{
    /**
     * @var SearchCriteriaInterface
     */
    private SearchCriteriaInterface $searchCriteria;

    /**
     * @var FilterGroupBuilder
     */
    private FilterGroupBuilder $filterGroupBuilder;

    /**
     * @var FilterBuilder
     */
    private FilterBuilder $filterBuilder;

    /**
     * @var OrderRepositoryInterface
     */
    private OrderRepositoryInterface $orderRepository;

    /**
     * @var UpdateOrderStatus
     */
    private UpdateOrderStatus $updateOrderStatus;

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @param FilterGroupBuilder $filterGroupBuilder
     * @param FilterBuilder $filterBuilder
     * @param SortOrderBuilder $sortOrderBuilder
     * @param OrderRepositoryInterface $orderRepository
     * @param UpdateOrderStatus $updateOrderStatus
     */
    public function __construct(
        SearchCriteriaInterface  $searchCriteria,
        FilterGroupBuilder       $filterGroupBuilder,
        FilterBuilder            $filterBuilder,
        SortOrderBuilder         $sortOrderBuilder,
        OrderRepositoryInterface $orderRepository,
        UpdateOrderStatus        $updateOrderStatus
    ) {
        $this->updateOrderStatus = $updateOrderStatus;
        $this->searchCriteria = $searchCriteria;
        $this->filterGroupBuilder = $filterGroupBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Cronjob Description
     *
     * @return void
     * @throws Exception
     */
    public function execute(): void
    {
        $filterGroups = [];
        $filterGroups[] = $this->filterGroupBuilder->create()->setData(FilterGroup::FILTERS, [
            $this->filterBuilder->create()
                ->setField('extension_attribute_payment_method_code.method')
                ->setValue(ConfigProvider::CODE)
        ]);

        $filterGroups[] = $this->filterGroupBuilder->create()->setData(FilterGroup::FILTERS, [
            $this->filterBuilder->create()
                ->setField('status')
                ->setConditionType('IN')
                ->setValue(['pending', 'pending_payment', 'payment_review'])
        ]);

        $ordersSearchCriteria = $this->searchCriteria->setFilterGroups($filterGroups);

        $orders = $this->orderRepository->getList($ordersSearchCriteria);
        foreach ($orders->getItems() as $order) {
            $this->updateOrderStatus->execute($order);
        }
    }
}
