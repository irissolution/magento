<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Controller\Processing;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Message\ManagerInterface;

class Redirect implements HttpGetActionInterface
{
    private const CART_URL = 'checkout/cart';

    /**
     * @var Session
     */
    private Session $session;

    /**
     * @var RedirectFactory
     */
    private RedirectFactory $redirectFactory;

    /**
     * @param Session $session
     * @param RedirectFactory $redirectFactory
     */
    public function __construct(
        Session          $session,
        RedirectFactory  $redirectFactory
    ) {
        $this->session = $session;
        $this->redirectFactory = $redirectFactory;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $redirectUrl = self::CART_URL;

        $order = $this->session->getLastRealOrder();
        if ($order->getId()) {
            if (in_array($order->getStatus(), ['pending', 'pending_payment', 'payment_review'])) {
                $redirectUrl = $order->getPayment()->getAdditionalInformation()['payment_link'] ?? null;
            }
        }

        return $this->redirectFactory->create()->setPath($redirectUrl);
    }
}
