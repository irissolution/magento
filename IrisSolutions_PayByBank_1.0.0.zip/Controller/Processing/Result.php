<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Controller\Processing;

use IrisSolutions\PayByBank\Gateway\Http\Client\UpdateOrderStatus;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface;

class Result implements HttpGetActionInterface
{
    private const CART_URL = 'checkout/cart';

    private const SUCCESS_URL = 'checkout/onepage/success';

    /**
     * @var Session
     */
    private Session $session;

    /**
     * @var ManagerInterface
     */
    private ManagerInterface $messageManager;

    /**
     * @var RedirectFactory
     */
    private RedirectFactory $redirectFactory;

    /**
     * @var UpdateOrderStatus
     */
    private UpdateOrderStatus $updateOrderStatus;

    /**
     * @param Session $session
     * @param ManagerInterface $messageManager
     * @param RedirectFactory $redirectFactory
     * @param UpdateOrderStatus $updateOrderStatus
     */
    public function __construct(
        Session $session,
        ManagerInterface $messageManager,
        RedirectFactory $redirectFactory,
        UpdateOrderStatus $updateOrderStatus
    ) {
        $this->session = $session;
        $this->messageManager = $messageManager;
        $this->redirectFactory = $redirectFactory;
        $this->updateOrderStatus = $updateOrderStatus;
    }

    /**
     * @inheritDoc
     * @throws LocalizedException
     * @throws \Exception
     */
    public function execute()
    {
        $redirectUrl = self::CART_URL;

        $order = $this->session->getLastRealOrder();
        if ($order->getId()) {
            $status = $this->updateOrderStatus->execute($order);

            if ($status == 'CONFIRMED') {
                $redirectUrl = self::SUCCESS_URL;
                $this->messageManager->addSuccessMessage(__('Successful payment. Thank you!')->render());
            } elseif ($status == 'WAITING') {
                $redirectUrl = self::SUCCESS_URL;
                $this->messageManager->addSuccessMessage(
                    __('Payment need to be processed. You will be notified!')->render()
                );
            } else {
                $this->session->restoreQuote();
                $this->messageManager->addErrorMessage(__('Please initiate payment again.')->render());
            }

        } else {
            $this->session->restoreQuote();
            $this->messageManager->addErrorMessage(__('Order not found. Please initiate payment again.')->render());
        }

        return $this->redirectFactory->create()->setPath($redirectUrl);
    }
}
