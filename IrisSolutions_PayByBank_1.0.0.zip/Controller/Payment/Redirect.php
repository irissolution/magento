<?php
/*
 * @package      Webcode_Fibank
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2021 Webcode Ltd. (https://webcode.bg/)
 * @license      See LICENSE.txt for license details.
 */

namespace IrisSolutions\PayByBank\Controller\Payment;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\PageFactory;

/**
 * @SuppressWarnings(PHPMD.LongVariableName)
 */
class Redirect implements HttpGetActionInterface
{
    /**
     * @var Session
     */
    private Session $checkoutSession;

    /**
     * @var PageFactory
     */
    private PageFactory $pageFactory;

    /**
     * @var RedirectFactory
     */
    private RedirectFactory $redirectFactory;

    /**
     * @param PageFactory $pageFactory
     * @param RedirectFactory $redirectFactory
     * @param Session $checkoutSession
     */
    public function __construct(
        PageFactory     $pageFactory,
        RedirectFactory $redirectFactory,
        Session         $checkoutSession
    ) {
        $this->pageFactory = $pageFactory;
        $this->redirectFactory = $redirectFactory;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * Execute action based on request and return result
     *
     * @return ResultInterface
     */
    public function execute(): ResultInterface
    {
        if (($order = $this->checkoutSession->getLastRealOrder()) && $order->getId()) {
            $page = $this->pageFactory->create();
            $block = $page->getLayout()->getBlock('paybybank_payment_form');
            $block->setData('order', $order);

            return $page;
        }

        return $this->redirectFactory->create()->setUrl('checkout/cart');
    }
}
