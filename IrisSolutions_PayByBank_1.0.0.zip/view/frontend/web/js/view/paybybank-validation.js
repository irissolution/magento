define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/additional-validators',
        'IrisSolutions_PayByBank/js/model/paybybank-validator'
    ],
    function (Component, additionalValidators, paybybankValidator) {
        'use strict';

        additionalValidators.registerValidator(paybybankValidator);
        return Component.extend({});
    }
);
