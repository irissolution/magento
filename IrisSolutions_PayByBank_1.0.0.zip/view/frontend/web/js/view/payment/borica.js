/*
 * @package      Webcode_Borica
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2020 Webcode Ltd. (https://webcode.bg/)
 * @license      See LICENSE.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'webcode_borica',
                component: 'Webcode_Borica/js/view/payment/method-renderer/borica'
            }
        );
        /** Add view logic here if needed */
        return Component.extend({});
    }
);
