/*
 * @package      Webcode_Borica
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2020 Webcode Ltd. (https://webcode.bg/)
 * @license      See LICENSE.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    ['jquery', 'Magento_Checkout/js/view/payment/default'],
    function ($, Component) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Webcode_Borica/payment/form'
            },
            redirectAfterPlaceOrder: false,

            afterPlaceOrder: function () {
                $.mage.redirect(window.checkoutConfig.payment.borica.redirectUrl);
            }
        });
    }
);
