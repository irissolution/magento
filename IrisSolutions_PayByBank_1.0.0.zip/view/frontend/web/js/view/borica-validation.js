/*
 * @package      Webcode_Borica
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2021 Webcode Ltd. (https://webcode.bg/)
 * @license      See LICENSE.txt for license details.
 */

define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/additional-validators',
        'IrisSolutions_PayByBank/js/model/paybybank-validator'
    ],
    function (Component, additionalValidators, paybybankValidator) {
        'use strict';
        additionalValidators.registerValidator(paybybankValidator);
        return Component.extend({});
    }
);
