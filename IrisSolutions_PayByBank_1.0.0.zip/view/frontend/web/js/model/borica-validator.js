/*
 * @package      Webcode_Borica
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2022 Webcode Ltd. (https://webcode.bg/)
 * @license      See LICENSE.txt for license details.
 */

define(
    ['mage/translate', 'Magento_Ui/js/model/messageList'],
    function ($t, messageList) {
        'use strict';
        return {
            validate: function () {
                const isValid = false; //Put your validation logic here

                return true; // TODO

                if (!isValid) {
                    messageList.addErrorMessage({message: $t('a possible failure message ...  ')});
                }

                return isValid;
            }
        }
    }
);