<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\UrlInterface;

class ConfigProvider implements ConfigProviderInterface
{
    public const CODE = 'irissolutions_paybybank';

    private const URL_PATH = 'paybybank/processing/redirect';

    /**
     * @var UrlInterface
     */
    private UrlInterface $url;

    /**
     * ConfigProvider constructor.
     *
     * @param UrlInterface $url
     */
    public function __construct(
        UrlInterface $url
    ) {
        $this->url = $url;
    }

    /**
     * @inheritDoc
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                'paybybank' => [
                    'redirectUrl' => $this->url->getUrl(self::URL_PATH)
                ]
            ]
        ];
    }
}
