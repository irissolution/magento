<?php
/*
 * @package      Webcode_Fibank
 *
 * @author       Kostadin Bashev (bashev@webcode.bg)
 * @copyright    Copyright © 2022 Webcode Ltd. (https://webcode.bg/)
 * @license      Visit https://webcode.bg/license/ for license details.
 */

namespace IrisSolutions\PayByBank\Model\Method;

use Magento\Payment\Model\Method\Adapter;
use Magento\Quote\Api\Data\CartInterface;
use Webcode\Fibank\Gateway\Config\Config;

class PayByBank extends Adapter
{
    public function isAvailable(CartInterface $quote = null)
    {
        if (!isset(Config::ALLOWED_CURRENCIES[$quote->getCurrency()->getBaseCurrencyCode()])
            && !isset(Config::ALLOWED_CURRENCIES[$quote->getCurrency()->getQuoteCurrencyCode()])
        ) {
            return false;
        }

        return parent::isAvailable($quote);
    }
}
