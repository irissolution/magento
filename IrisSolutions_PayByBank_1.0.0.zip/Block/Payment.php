<?php

namespace IrisSolutions\PayByBank\Block;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Model\Order;
use IrisSolutions\PayByBank\Gateway\Config\Config;

/**
 * @method getOrder()
 */
class Payment extends Template
{
    /**
     * @var Config
     */
    public Config $config;

    /**
     * @var UrlInterface
     */
    private UrlInterface $url;

    /**
     * @param Config $config
     * @param UrlInterface $url
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Config $config,
        UrlInterface $url,
        Context $context,
        array $data = []
    ) {
        $this->config = $config;
        $this->url = $url;

        parent::__construct($context, $data);
    }

    /**
     * Prepare params array to send it to gateway page
     *
     * @param int $transactionType
     * @param Order|bool $order
     * @param float $amount
     *
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Exception
     */
    private function getOrderData(int $transactionType, $order = false, float $amount = 0): array
    {
        if (!$order) {
            $order = $this->getOrder();
        }

        // TODO
        $date = new \DateTime($order->getCreatedAt(), new \DateTimeZone('UTC'));
        // $date = new DateTime(null, new DateTimeZone('UTC'));
        $gmtDate = $date->format('YmdHis');
        $date->setTimezone(new \DateTimeZone('Europe/Sofia'));

        $boricaOrder = $this->convertOrderIdToBoricaOrder($order->getId());

        // if ($transactionType === self::TRTYPE_REFUND) {
        //     $date = new \DateTime(null, new \DateTimeZone('UTC'));
        //     $gmtDate = $date->format('YmdHis');
        //     $boricaOrder = $date->format('His');
        //     $date->setTimezone(new DateTimeZone('Europe/Sofia'));
        // }

        // TERMINAL, TRTYPE, AMOUNT, CURRENCY, ORDER, MERCHANT, TIMESTAMP, NONCE
        $signatureData = [
            'TERMINAL' => $this->config->getTerminalId($order->getStoreId()),
            'TRTYPE' => $transactionType,
            'AMOUNT' => $this->getOrderAmount($order, $amount),
            'CURRENCY' => 'BGN',
            'ORDER' => $boricaOrder,
            'MERCHANT' => $this->config->getMerchantId($order->getStoreId()),
            'TIMESTAMP' => $gmtDate,
            'NONCE' => strtoupper(bin2hex(openssl_random_pseudo_bytes(16))),
        ];

        $data = [
            'DESC' => __('Order') . ' ' . $order->getIncrementId(),
            'MERCH_NAME' => $order->getStore()->getFrontendName(),
            'MERCH_URL' => $order->getStore()->getBaseUrl(),
            'MERCH_GMT' => substr($date->format('P'), 0, 3),
            'EMAIL' => $this->config->getStoreEmail(),
            'COUNTRY' => $order->getBillingAddress()->getCountryId(),
            'BACKREF' => $this->url->getUrl('borica/payment/result'),
            'LANG' => 'bg',
            'ADDENDUM' => 'AD,TD',
            'AD.CUST_BOR_ORDER_ID' => $boricaOrder . '@' . $order->getIncrementId(),
            'P_SIGN' => $this->signData($signatureData),
        ];

        // if ($transactionType === self::TRTYPE_REFUND) {
        //     $data['RRN'] = $order->getPayment()->getAdditionalInformation('RRN');
        //     $data['INT_REF'] = $order->getPayment()->getAdditionalInformation('INT_REF');
        // }

        return array_merge($signatureData, $data);
    }

    /**
     * @param $orderId
     *
     * @return string
     */
    private function convertOrderIdToBoricaOrder($orderId): string
    {
        if (strlen($orderId) > 6) {
            $orderId = substr($orderId, -6);
        }

        return str_pad($orderId, 6, '0', STR_PAD_LEFT);
    }

    /**
     * @param \Magento\Sales\Model\Order $order
     * @param float $amount
     *
     * @return string
     */
    private function getOrderAmount(Order $order, float $amount = 0): string
    {
        if ($amount == 0) {
            $amount = $order->getBaseGrandTotal();
        }

        // $currency = array_first(Config::ALLOWED_CURRENCIES);
        // if (isset(Config::ALLOWED_CURRENCIES[$this->getOrder()->getOrderCurrencyCode()])) {
        //     $amount = $this->getOrder()->getGrandTotal();
        //     $currency = Config::ALLOWED_CURRENCIES[$this->getOrder()->getOrderCurrencyCode()];
        // }
        // $baseCurrency = $currency;
        // $currentCurrency = $order->getOrderCurrencyCode();
        // if ($baseCurrency != $currentCurrency) {
        //     $rate = 1;
        //     $rates = Mage::getModel('directory/currency')->getCurrencyRates($baseCurrency, $currentCurrency);
        //     if (!empty($rates[$currentCurrency])) {
        //         $rate = $rates[$currentCurrency];
        //     }
        //
        //     $amount = $order->getGrandTotal()/$rate;
        // }

        return number_format($amount, 2, '.', '');
    }

    /**
     * Generate Request
     *
     * @param $data
     *
     * @return string url
     */
    private function signData($data): string
    {
        $sign = $this->signatureData($data);

        $pkeyid = openssl_get_privatekey($this->config->getPrivateKey(), $this->config->getPrivateKeyPassword());
        openssl_sign($sign, $signature, $pkeyid, OPENSSL_ALGO_SHA256);

        return strtoupper(bin2hex($signature));
    }

    /**
     * @param $data
     *
     * @return string
     * @return string
     */
    protected function signatureData($data): string
    {
        $sign = '';
        foreach ($data as $value) {
            if ($value !== '-') {
                $sign .= mb_strlen($value);
            }
            $sign .= $value;
        }

        return $sign;
    }

    /**
     * Return url of payment method
     *
     * @return array
     * @throws \Exception
     */
    public function getPaymentData(): array
    {
        if ($this->getData('order')->getId()) {
            return $this->getOrderData(1);
        }
    }
}
