<?php

declare(strict_types=1);

namespace IrisSolutions\PayByBank\Block;

use Magento\Framework\DataObject;
use Magento\Framework\Exception\LocalizedException;

class Info extends \Magento\Payment\Block\Info
{
    /**
     * Prepare Payment specific information.
     *
     * @param DataObject|array|null $transport
     *
     * @return DataObject
     * @throws LocalizedException
     *
     * @SuppressWarnings(PHPMD.CamelCaseMethodName)
     */
    protected function _prepareSpecificInformation($transport = null): DataObject /** @phpstan-ignore-line */
    {
        $transport = parent::_prepareSpecificInformation($transport);
        if ($this->getIsSecureMode()) {
            $payment = $this->getInfo();

            $transport->addData((array) $payment->getAdditionalInformation());
        }

        return $transport;
    }
}
